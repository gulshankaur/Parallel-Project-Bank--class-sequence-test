package com.cg.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.exception.AccountException;
import com.cg.exception.AmountException;
import com.cg.exception.NameException;
import com.cg.exception.PhoneNumberException;
import com.cg.service.AccountServiceImpl;

public class BankTest {
	//These comprise of the passed test cases as well as the failure test cases which have been corrected
	@Test
	public void ValidateNameTrue() throws NameException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(true, as.validateName("Gulshan"));
	}
	@Test 
	public void ValidateName() throws NameException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(false, as.validateName("Gulshan523"));
		assertEquals(false, as.validateName("Gulshan*9556"));
		assertEquals(false, as.validateName("85621"));
		assertEquals(false, as.validateName("gulshan"));
	}
	
	@Test
	public void ValidatePhonNumberTrue() throws PhoneNumberException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(true, as.validatePhoneNumber("9800887755"));
	}
	
	@Test
	public void ValidatePhoneNumber() throws PhoneNumberException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(false, as.validatePhoneNumber("98632"));
		assertEquals(false, as.validatePhoneNumber("4634862470"));
		assertEquals(false, as.validatePhoneNumber("6317"));
		assertEquals(false, as.validatePhoneNumber("testing"));
		assertEquals(false, as.validatePhoneNumber("@#*%"));
	}
	
	@Test
	public void ValidateAmountTrue() throws AmountException{
		AccountServiceImpl bs = new AccountServiceImpl();
		assertEquals(true, bs.validateAmount("150"));
	}
	
	@Test 
	public void ValidateAmount() throws AmountException{
		AccountServiceImpl bs = new AccountServiceImpl();
		assertEquals(false, bs.validateAmount("0"));
		assertEquals(false, bs.validateAmount("-100"));
	}
	
	@Test
	public void ValidateAccountTrue() throws AccountException{
		AccountServiceImpl bs = new AccountServiceImpl();
		assertEquals(true, bs.validateAmount("12345"));
		
	}
	@Test 
	public void ValidateAccount() throws AmountException{
		AccountServiceImpl bs = new AccountServiceImpl();
		assertEquals(false, bs.validateAmount("0"));
		assertEquals(false, bs.validateAmount("-12345"));
	}
	

}
